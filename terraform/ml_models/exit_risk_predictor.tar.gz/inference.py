
import json
import pickle
import os

class SimpleExitRiskPredictor:
    """
    Simple rule-based exit risk predictor
    """
    
    def __init__(self):
        self.feature_names = [
            'error_count', 'retry_count', 'help_requests', 'session_duration',
            'page_exits', 'form_abandons', 'click_frustration', 'success_rate',
            'engagement_score', 'time_since_last_success', 'session_count',
            'unique_pages_visited', 'average_time_per_page'
        ]
        
        # Simple weights for rule-based prediction
        self.weights = {
            'error_count': 0.2,
            'retry_count': 0.15,
            'help_requests': 0.3,
            'session_duration': -0.05,
            'page_exits': 0.1,
            'form_abandons': 0.25,
            'click_frustration': 0.15,
            'success_rate': -0.4,
            'engagement_score': -0.3,
            'time_since_last_success': 0.1,
            'session_count': -0.05,
            'unique_pages_visited': -0.02,
            'average_time_per_page': 0.02
        }
        
        self.threshold = 0.6
    
    def predict_proba(self, X):
        if isinstance(X, list):
            X = [X] if not isinstance(X[0], list) else X
        
        probabilities = []
        
        for instance in X:
            risk_score = 0
            
            for i, feature_name in enumerate(self.feature_names):
                if i < len(instance):
                    value = instance[i]
                    weight = self.weights.get(feature_name, 0)
                    
                    if feature_name == 'success_rate':
                        value = max(0, min(1, value))
                    elif feature_name == 'engagement_score':
                        value = max(0, min(100, value)) / 100
                    elif feature_name in ['session_duration', 'time_since_last_success', 'average_time_per_page']:
                        value = min(value / 300, 2)
                    elif feature_name in ['error_count', 'retry_count', 'help_requests', 'page_exits', 'form_abandons', 'click_frustration']:
                        value = min(value / 10, 1)
                    
                    risk_score += value * weight
            
            risk_prob = max(0, min(1, (risk_score + 1) / 2))
            probabilities.append([1 - risk_prob, risk_prob])
        
        return probabilities
    
    def predict(self, X):
        probabilities = self.predict_proba(X)
        return [1 if prob[1] > self.threshold else 0 for prob in probabilities]

def model_fn(model_dir):
    """Load the model for inference"""
    model_path = os.path.join(model_dir, 'exit_risk_model.pkl')
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    return model

def input_fn(request_body, request_content_type):
    """Parse input data for inference"""
    if request_content_type == 'application/json':
        input_data = json.loads(request_body)
        
        if 'instances' in input_data:
            instances = input_data['instances']
        else:
            instances = [input_data]
        
        # Convert to list of lists
        processed_instances = []
        required_features = [
            'error_count', 'retry_count', 'help_requests', 'session_duration',
            'page_exits', 'form_abandons', 'click_frustration', 'success_rate',
            'engagement_score', 'time_since_last_success', 'session_count',
            'unique_pages_visited', 'average_time_per_page'
        ]
        
        for instance in instances:
            feature_values = []
            for feature in required_features:
                feature_values.append(instance.get(feature, 0.0))
            processed_instances.append(feature_values)
        
        return processed_instances
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    """Make predictions using the loaded model"""
    try:
        probabilities = model.predict_proba(input_data)
        predictions = model.predict(input_data)
        
        results = []
        for i, (pred, prob) in enumerate(zip(predictions, probabilities)):
            results.append({
                'prediction': int(pred),
                'probability': float(prob[1]),
                'confidence': float(max(prob)),
                'risk_score': float(prob[1] * 100)
            })
        
        return results
    except Exception as e:
        return {'error': str(e)}

def output_fn(prediction, content_type):
    """Format the prediction output"""
    if content_type == 'application/json':
        return json.dumps({
            'predictions': prediction,
            'model_version': '1.0',
            'model_type': 'simple_rule_based'
        })
    else:
        raise ValueError(f"Unsupported content type: {content_type}")
