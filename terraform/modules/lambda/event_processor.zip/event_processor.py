import json
import boto3
import os
from datetime import datetime
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
timestream_write = boto3.client('timestream-write')
bedrock_agent = boto3.client('bedrock-agent-runtime')

# Environment variables
ENVIRONMENT = os.environ.get('ENVIRONMENT', 'dev')
USER_PROFILES_TABLE = os.environ.get('USER_PROFILES_TABLE')
USER_EVENTS_TABLE = os.environ.get('USER_EVENTS_TABLE')
STRUGGLE_SIGNALS_TABLE = os.environ.get('STRUGGLE_SIGNALS_TABLE')
VIDEO_ENGAGEMENT_TABLE = os.environ.get('VIDEO_ENGAGEMENT_TABLE')
TIMESTREAM_DATABASE = os.environ.get('TIMESTREAM_DATABASE')

def lambda_handler(event, context):
    """
    Process user events from Kinesis Data Stream
    """
    try:
        for record in event['Records']:
            # Decode Kinesis data
            payload = json.loads(record['kinesis']['data'])
            
            # Process the user event
            process_user_event(payload)
            
        return {
            'statusCode': 200,
            'body': json.dumps('Events processed successfully')
        }
        
    except Exception as e:
        logger.error(f"Error processing events: {str(e)}")
        raise e

def process_user_event(event_data):
    """
    Process individual user event
    """
    try:
        # Store event in DynamoDB
        store_user_event(event_data)
        
        # Store time-series data in Timestream
        store_timestream_data(event_data)
        
        # Update user profile
        update_user_profile(event_data)
        
        # Check for struggle signals
        if detect_struggle_signal(event_data):
            trigger_intervention(event_data)
            
        # Process video engagement
        if event_data.get('eventType') == 'video_engagement':
            process_video_engagement(event_data)
            
    except Exception as e:
        logger.error(f"Error processing user event: {str(e)}")
        raise e

def store_user_event(event_data):
    """
    Store user event in DynamoDB
    """
    table = dynamodb.Table(USER_EVENTS_TABLE)
    
    # Add TTL (30 days from now)
    ttl = int(datetime.now().timestamp()) + (30 * 24 * 60 * 60)
    
    item = {
        'userId': event_data['userId'],
        'timestamp': event_data['timestamp'],
        'eventType': event_data['eventType'],
        'sessionId': event_data['sessionId'],
        'eventData': event_data.get('eventData', {}),
        'deviceInfo': event_data.get('deviceInfo', {}),
        'userContext': event_data.get('userContext', {}),
        'ttl': ttl
    }
    
    table.put_item(Item=item)

def store_timestream_data(event_data):
    """
    Store time-series data in Timestream
    """
    try:
        records = []
        
        # Create base record
        record = {
            'Time': str(event_data['timestamp']),
            'TimeUnit': 'MILLISECONDS',
            'Dimensions': [
                {'Name': 'userId', 'Value': event_data['userId']},
                {'Name': 'eventType', 'Value': event_data['eventType']},
                {'Name': 'sessionId', 'Value': event_data['sessionId']}
            ]
        }
        
        # Add event-specific metrics
        if event_data['eventType'] == 'video_engagement':
            record.update({
                'MeasureName': 'video_watch_duration',
                'MeasureValue': str(event_data['eventData'].get('duration', 0)),
                'MeasureValueType': 'BIGINT'
            })
            records.append(record.copy())
            
            record.update({
                'MeasureName': 'video_completion_rate',
                'MeasureValue': str(event_data['eventData'].get('completionRate', 0)),
                'MeasureValueType': 'DOUBLE'
            })
            records.append(record.copy())
            
        elif event_data['eventType'] == 'feature_interaction':
            record.update({
                'MeasureName': 'feature_attempt_count',
                'MeasureValue': str(event_data['eventData'].get('attemptCount', 1)),
                'MeasureValueType': 'BIGINT'
            })
            records.append(record)
        
        if records:
            timestream_write.write_records(
                DatabaseName=TIMESTREAM_DATABASE,
                TableName='user-metrics',
                Records=records
            )
            
    except Exception as e:
        logger.error(f"Error storing Timestream data: {str(e)}")

def update_user_profile(event_data):
    """
    Update user profile based on event
    """
    table = dynamodb.Table(USER_PROFILES_TABLE)
    
    try:
        # Update last active timestamp and increment session count
        table.update_item(
            Key={'userId': event_data['userId']},
            UpdateExpression='SET lastActiveAt = :timestamp, totalSessions = if_not_exists(totalSessions, :zero) + :one',
            ExpressionAttributeValues={
                ':timestamp': event_data['timestamp'],
                ':zero': 0,
                ':one': 1
            }
        )
    except Exception as e:
        logger.error(f"Error updating user profile: {str(e)}")

def detect_struggle_signal(event_data):
    """
    Detect if user is struggling with a feature
    """
    if event_data['eventType'] == 'feature_interaction':
        attempt_count = event_data['eventData'].get('attemptCount', 1)
        if attempt_count >= 2:
            store_struggle_signal(event_data)
            return True
    return False

def store_struggle_signal(event_data):
    """
    Store struggle signal in DynamoDB
    """
    table = dynamodb.Table(STRUGGLE_SIGNALS_TABLE)
    
    attempt_count = event_data['eventData'].get('attemptCount', 1)
    severity = 'low'
    if attempt_count >= 5:
        severity = 'critical'
    elif attempt_count >= 3:
        severity = 'high'
    elif attempt_count >= 2:
        severity = 'medium'
    
    # Add TTL (7 days from now)
    ttl = int(datetime.now().timestamp()) + (7 * 24 * 60 * 60)
    
    item = {
        'userId': event_data['userId'],
        'featureId': event_data['eventData'].get('feature', 'unknown'),
        'detectedAt': event_data['timestamp'],
        'signalType': 'repeated_attempts',
        'severity': severity,
        'attemptCount': attempt_count,
        'timeSpent': event_data['eventData'].get('duration', 0),
        'resolved': False,
        'ttl': ttl
    }
    
    table.put_item(Item=item)

def trigger_intervention(event_data):
    """
    Trigger AI intervention through Bedrock Agent
    """
    try:
        intervention_request = {
            'userId': event_data['userId'],
            'struggleType': event_data['eventData'].get('feature', 'unknown'),
            'attemptCount': event_data['eventData'].get('attemptCount', 1),
            'context': event_data.get('userContext', {})
        }
        
        # Note: Bedrock Agent ID would be configured in environment
        # This is a placeholder for the actual implementation
        logger.info(f"Triggering intervention for user {event_data['userId']}")
        
    except Exception as e:
        logger.error(f"Error triggering intervention: {str(e)}")

def process_video_engagement(event_data):
    """
    Process video engagement data
    """
    table = dynamodb.Table(VIDEO_ENGAGEMENT_TABLE)
    
    try:
        # Calculate interest score based on completion rate and watch time
        completion_rate = event_data['eventData'].get('completionRate', 0)
        duration = event_data['eventData'].get('duration', 0)
        interest_score = min(100, (completion_rate * 0.7 + min(duration / 300, 1) * 0.3) * 100)
        
        table.put_item(Item={
            'userId': event_data['userId'],
            'videoId': event_data['eventData'].get('videoId', 'unknown'),
            'lastWatchedAt': event_data['timestamp'],
            'viewCount': 1,
            'totalWatchTime': duration,
            'completionRate': completion_rate,
            'interestScore': int(interest_score)
        })
        
    except Exception as e:
        logger.error(f"Error processing video engagement: {str(e)}")